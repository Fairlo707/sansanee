package com.sourcey.materialloginexample

import android.arch.lifecycle.ViewModel

class LeftViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
